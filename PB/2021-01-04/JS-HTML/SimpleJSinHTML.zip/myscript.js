let dt=new Date(); // create a date object 
//alert("message");
document.body.innerHTML="<h1> This is the current date & time : " + dt + "</h1>"; //DOM